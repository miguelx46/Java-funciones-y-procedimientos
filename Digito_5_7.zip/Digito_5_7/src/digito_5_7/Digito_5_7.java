/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package digito_5_7;

import java.util.Scanner;

/**
 *
 * @author migue
 */
public class Digito_5_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int n; 
        Scanner l = new Scanner(System.in);
        System.out.println("Digite la cantidad de numeros");
        n = l.nextInt();
        int v[] = new int [n];
        boolean v2[] = new boolean [n];
        for (int i = 0; i < v.length; i++) {
            System.out.println("Digite un numero");
             v[i] = l.nextInt();
              while (v[i] < 10000) {
                  System.out.println("El numero no tiene 5 cifras, ingrese otro");
                  v[i] = l.nextInt();
              }
        }
        dig5_7(v);
        
    }
    public static void dig5_7 (int v[]) {
        int num5 = 0, num7 = 0, contnum = 0, numtemp, tempcifras = 0, tempdig1, tempdig2, tempdig3, tempdig4, tempdig5; ;
        boolean temptiene5 = false, temptiene7 = false;
        for (int i = 0; i < v.length; i++) {
            numtemp = v[i];
            tempdig1 = numtemp/10000;
            tempdig2 = numtemp%10000;
            tempdig3 = (numtemp/100)%10;
            tempdig4 = (numtemp&100)/10;
            tempdig5 = numtemp&10;
             if(tempdig1 == 7 || tempdig2 == 7 || tempdig3 == 7 || tempdig4 == 7 || tempdig5 == 7) {
                 num7 =+ 1;
             }
             if(tempdig1 == 5 || tempdig2 == 5 || tempdig3 == 5 || tempdig4 == 5 || tempdig5 == 5) {
                 num5 =+ 1;
             }
        tempdig1 = 0;
        tempdig2 = 0;
        tempdig3 = 0;
        tempdig4 = 0;
        tempdig5 = 0;    
        }
        System.out.println("Cantidad de usuarios: " +num5+ " , " +num7);        
    } 
}
