/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package funcion_devolver_1o.pkg1;

import java.util.Scanner;

/**
 *
 * @author migue
 */
public class Funcion_devolver_1o1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner l = new Scanner(System.in);
        System.out.println("Digite un numero");
        int x = l.nextInt();
        int num = funcion_1(x);
        System.out.println();
    }
        //Funcion devolver 1 o -1
    public static int funcion_1(int x) {
        if (x > 0) { 
            return 1;
        } else if (x < 0) {
            return -1;    
        }
    } 
}
