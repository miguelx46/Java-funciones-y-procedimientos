/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package factorial_swing_macm;

/**
 *
 * @author migue
 */
public class Factorial_swing_macm {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GUI frame = new GUI();
        frame.setVisible(true);
        frame.setSize(550, 420);
    }
    
}
