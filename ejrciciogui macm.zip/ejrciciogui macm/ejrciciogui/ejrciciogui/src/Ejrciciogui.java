/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


/**
 *
 * @author johanysp
 */
public class Ejrciciogui {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GUI1 frame = new GUI1 ();
        frame.setVisible(true);
        // TODO code application logic here
    }
    
}
