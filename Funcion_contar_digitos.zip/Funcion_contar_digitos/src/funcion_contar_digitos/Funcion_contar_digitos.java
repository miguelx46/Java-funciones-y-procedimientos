/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package funcion_contar_digitos;

import java.util.Scanner;

/**
 *
 * @author migue
 */
public class Funcion_contar_digitos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner l = new Scanner(System.in);
        int dig;
        System.out.println("Digite un número");
        dig = l.nextInt();
        int x = cont_dig(dig);
        System.out.println("Cantidad de digitos del numero" +x);
    }
    public static int cont_dig (int dig) {
        int contdig = 0;
      while (dig > 9) {
          dig = dig / 10;
          contdig = contdig + 1;
      }
      return contdig;
    }
}
