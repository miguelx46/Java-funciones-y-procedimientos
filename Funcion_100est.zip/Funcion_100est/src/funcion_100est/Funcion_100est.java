package funcion_100est;

import java.util.Scanner;

/**
 *
 * @author migue
 */
public class Funcion_100est {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner l = new Scanner(System.in);
        int a, b, c, d;
        int v[] = new int [100];
        for (int i = 0; i < v.length; i++) {
            System.out.println("Digite una nota");
            v[i] = l.nextInt();
        }
        a = calcmen50(v);
        b = calcmen70(v);
        c = calcmen80(v);
        d = calcmas80(v);
        a = 1; b = 2; c = 3; d = 4;
        System.out.println(a+ "," +b+ "," +c+ "," +d);
    }
    public static int calcmen50(int v[]) {
        int contmen50 = 0;
        for (int i = 0; i < v.length; i++) {
            if (v[i] < 50) {
                contmen50 += 1;
            }   
        }
        return contmen50;
    }
    public static int calcmen70(int v[]) {
        int contmen70 = 0;
        for (int i = 0; i < v.length; i++) {
            if (v[i] >= 50 & v[i] < 70) {
                contmen70 += 1;
            }            
        }
        return contmen70;
    }
    public static int calcmen80 (int v[]) {
        int contmen80 = 0;
        for (int i = 0; i < v.length; i++) {
            if (v[i] >= 70 & v[i] < 80) {
                contmen80 += 1;
            }    
        }
        return contmen80;
    }
    public static int calcmas80 (int v[]) {
        int contmas80 = 0;
        for (int i = 0; i < v.length; i++) {
           if (v[i] >= 80) {
               contmas80 += 1;
           }
        }
        return contmas80;
    }
}
